@echo off
setlocal enabledelayedexpansion

:: ============================================
:: Zip Frontend Project - exclude bin & obj
:: ============================================

set "SCRIPT_DIR=%~dp0"
set "PS_SCRIPT=%SCRIPT_DIR%zip-frontend.ps1"

:: Run the PowerShell script
powershell -NoProfile -ExecutionPolicy Bypass -File "%PS_SCRIPT%"

if %ERRORLEVEL% NEQ 0 (
    echo.
    echo [ERROR] Zip process failed (exit code: %ERRORLEVEL%^)
    pause
    exit /b 1
)

pause
